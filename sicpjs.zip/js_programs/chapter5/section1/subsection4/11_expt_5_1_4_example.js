expt(3, 4);
