stream_ref(fibs, 20);
