stream_ref(fibs, 50);
