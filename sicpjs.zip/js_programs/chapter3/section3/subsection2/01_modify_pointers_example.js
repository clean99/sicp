const q = pair(1, 2);
set_front_ptr(q, 42);	
front_ptr(q);
