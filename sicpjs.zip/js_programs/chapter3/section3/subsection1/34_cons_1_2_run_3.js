const x = pair(1, 2);
set_head(x, 3);
head(x);
