const x = list(list("a", "b"), "c");
const y = list("e", "f");
