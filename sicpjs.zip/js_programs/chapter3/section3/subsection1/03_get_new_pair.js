// The book proposes a primitive function get_new_pair.
// Since JavaScript does not provide such a function, let's
// define it as follows, for the sake of the example.

function get_new_pair() {
    return pair(undefined, undefined);
}
{
