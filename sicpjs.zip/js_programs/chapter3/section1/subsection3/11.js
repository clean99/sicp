25 - 20;

// expected: 5
