// make_monitored function to be written by students
const s = make_monitored(math_sqrt);
s(100);
s("how many calls");
