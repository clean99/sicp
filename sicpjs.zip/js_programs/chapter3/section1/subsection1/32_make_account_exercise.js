// make_account function to be written by students
const acc = make_account(100, "secret password");
