make_rat(4, 6);
