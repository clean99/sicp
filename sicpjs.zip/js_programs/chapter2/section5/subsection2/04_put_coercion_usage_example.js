// chapter=3 
get_coercion("javascript_number", "complex");
